package JavaProject;
public class Square extends Rectangle{
	public Square(double width, double length) {
		super(width, length);
	}

}